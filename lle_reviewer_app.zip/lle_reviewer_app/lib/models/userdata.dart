class UserData{

  String uid;
  String email;

  UserData({this.uid, this.email});

}