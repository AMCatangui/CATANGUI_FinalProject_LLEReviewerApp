package com.taufiqalhasib.flutter_quiz_maker_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
